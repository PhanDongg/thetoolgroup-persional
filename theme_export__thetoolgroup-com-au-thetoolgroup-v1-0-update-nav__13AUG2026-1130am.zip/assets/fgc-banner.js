(window.webpackJsonp = window.webpackJsonp || []).push([
    [10],
    {
        BJp4: function (t, e, n) {
            "use strict";
            n.d(e, "a", function () {
                return r;
            });
            var r = function t(e) {
                !(function (t, e) {
                    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
                })(this, t),
                    (this.component = e);
            };
        },
        v8Se: function (t, e, n) {
            "use strict";
            n.r(e),
                n.d(e, "default", function () {
                    return r;
                });
            var i = n("A0bn"),
                c = n("BJp4");
            function u(t) {
                return (u =
                    "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                        ? function (t) {
                              return typeof t;
                          }
                        : function (t) {
                              return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
                          })(t);
            }
            function l(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var r = e[n];
                    (r.enumerable = r.enumerable || !1), (r.configurable = !0), "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r);
                }
            }
            function a(t, e) {
                return (a =
                    Object.setPrototypeOf ||
                    function (t, e) {
                        return (t.__proto__ = e), t;
                    })(t, e);
            }
            function f(i) {
                return function () {
                    var t,
                        e,
                        n,
                        r = s(i);
                    if (
                        (function () {
                            if ("undefined" == typeof Reflect || !Reflect.construct) return;
                            if (Reflect.construct.sham) return;
                            if ("function" == typeof Proxy) return 1;
                            try {
                                return Date.prototype.toString.call(Reflect.construct(Date, [], function () {})), 1;
                            } catch (t) {
                                return;
                            }
                        })()
                    ) {
                        var o = s(this).constructor;
                        t = Reflect.construct(r, arguments, o);
                    } else t = r.apply(this, arguments);
                    return (
                        (e = this),
                        !(n = t) || ("object" !== u(n) && "function" != typeof n)
                            ? (function (t) {
                                  if (void 0 !== t) return t;
                                  throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                              })(e)
                            : n
                    );
                };
            }
            function s(t) {
                return (s = Object.setPrototypeOf
                    ? Object.getPrototypeOf
                    : function (t) {
                          return t.__proto__ || Object.getPrototypeOf(t);
                      })(t);
            }
            var r = (function () {
                !(function (t, e) {
                    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                    (t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } })), e && a(t, e);
                })(o, c["a"]);
                var t,
                    e,
                    n,
                    r = f(o);
                function o(t) {
                    var e;
                    return (
                        (function (t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
                        })(this, o),
                        ((e = r.call(this, t)).paginationElement = e.component.querySelector(".banner-slider-pagination-page")),
                        window.requestIdleCallback
                            ? requestIdleCallback(function () {
                                  e.initSlider();
                              })
                            : e.initSlider(),
                        e
                    );
                }
                return (
                    (t = o),
                    (e = [
                        {
                            key: "initSlider",
                            value: function () {
                              console.log("banner loaded");
                                (this.glideActive = !1), (this.glideElement = this.component.querySelector(".glide"));
                                var t = this.glideElement.querySelectorAll(".banner-slide");
                                1 < t.length ? ((this.glide = new i.a(this.glideElement, { type: "carousel", gap: 0, autoplay: 8000 }).mount()), this.glideElement.classList.add("glide--active")) : t[0].classList.add("glide__slide--active");
                            },
                        },
                    ]) && l(t.prototype, e),
                    n && l(t, n),
                    o
                );
            })();
        },
    },
]);
